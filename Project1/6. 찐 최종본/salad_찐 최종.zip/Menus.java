public class Menus
{
	public static final int E_MINUS = -1;
	public static final int E_ONE = 1;
	public static final int E_TWO = 2;
	public static final int E_THREE = 3;
	public static final int E_FOUR = 4;
	public static final int E_FIVE = 5;
	public static final int E_SECRETCODE = 4646;
}